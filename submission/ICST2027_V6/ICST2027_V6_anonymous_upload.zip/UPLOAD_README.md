# Anonymous ICST 2027 V6 upload bundle

- `paper.pdf`: anonymous 9-page IEEE conference-format manuscript.
- `replication_package.zip`: sanitized V5 historical evidence plus V6 evidence,
  source, scripts, and reproduction instructions.

Human authors must complete HotCRP authorship/COI, originality, simultaneous-
submission, licensing, and artifact-access decisions before upload.
