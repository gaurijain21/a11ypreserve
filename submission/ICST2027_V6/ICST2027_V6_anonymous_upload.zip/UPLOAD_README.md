# Anonymous ICST 2027 upload bundle

- `paper.pdf`: anonymous 10-page IEEE conference-format manuscript.
- `replication_package.zip`: sanitized V5 historical evidence plus the current
  evidence, source, scripts, and reproduction instructions.

Human authors must complete HotCRP authorship/COI, originality, simultaneous-
submission, licensing, and artifact-access decisions before upload.
