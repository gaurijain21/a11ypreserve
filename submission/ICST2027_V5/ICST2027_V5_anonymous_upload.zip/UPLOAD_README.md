# Anonymous ICST 2027 V5 upload bundle

- `paper.pdf`: anonymous 9-page IEEE conference-format Research Papers manuscript.
- `replication_package.zip`: sanitized V5 replication package containing the frozen V4 evidence and completed V5 hardening records.

Before portal submission, complete the HotCRP author/COI fields, final author-anonymity check, originality and simultaneous-submission declarations, and any portal-specific artifact license/access settings.
